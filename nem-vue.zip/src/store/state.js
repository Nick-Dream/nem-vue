export default {
  menu: [],
}
