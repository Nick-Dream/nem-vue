export const SERVER_ERROR = 'serverError'
export const SET_MENUS = 'setMenus'
